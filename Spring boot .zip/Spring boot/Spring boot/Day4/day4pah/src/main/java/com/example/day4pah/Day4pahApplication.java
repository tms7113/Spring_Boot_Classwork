package com.example.day4pah;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Day4pahApplication {

	public static void main(String[] args) {
		SpringApplication.run(Day4pahApplication.class, args);
	}

}
