package com.example.day6cw1;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Day6cw1Application {

	public static void main(String[] args) {
		SpringApplication.run(Day6cw1Application.class, args);
	}

}
