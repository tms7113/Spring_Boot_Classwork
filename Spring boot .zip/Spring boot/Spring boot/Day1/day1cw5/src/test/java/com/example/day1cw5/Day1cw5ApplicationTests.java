package com.example.day1cw5;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Day1cw5ApplicationTests {

	@Test
	void contextLoads() {
	}

}
