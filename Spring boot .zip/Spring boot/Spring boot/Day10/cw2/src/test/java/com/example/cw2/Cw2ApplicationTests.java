package com.example.cw2;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Cw2ApplicationTests {

	@Test
	void contextLoads() {
	}

}
